package project3;

public class Cell {
	public int x;
	public int y;
	public int num;
	
	public Cell(int x, int y, int num){
		this.x = x;
		this.y = y;
		this.num = num;
	}
}
