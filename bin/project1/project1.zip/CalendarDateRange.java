package project1;

public class CalendarDateRange {
	int years;
	int days;
	
	public CalendarDateRange(int years, int days){
		this.years = years;
		this.days = days;
	}

	public CalendarDateRange() {
		// TODO Auto-generated constructor stub
	}
}
